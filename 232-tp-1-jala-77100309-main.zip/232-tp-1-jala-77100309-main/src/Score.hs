module Score (score) where

import State (State)

-- | Renvoie le score pour un état 'state'.
score :: State -> Int
score state = undefined

