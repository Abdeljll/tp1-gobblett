module Main (main) where

-- | Lance l'interface du jeu.
main :: IO ()
main = undefined

