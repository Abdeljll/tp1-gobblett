module State (State) where

data State = TODO

