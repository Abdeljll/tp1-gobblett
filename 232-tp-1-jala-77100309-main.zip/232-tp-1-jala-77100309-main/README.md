# TP1 : Gobblet

Voir les instructions dans [Instructions.md](Instructions.md).

## Identification

- Cours      : Programmation fonctionnelle et logique
- Sigle      : INF6120
- Groupe     : 020
- Session    : Automne 2023
- Auteur(s)  : `<nom>` (`<code permanent>`)

Indiquez les extensions réalisées ci-dessous.

